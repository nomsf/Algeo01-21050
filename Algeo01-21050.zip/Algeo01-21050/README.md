# Algeo01-21050

**Deadline Tubes** : 3 Oktober 2022

Pembagian Tugas:
- SPL_Metode Eliminasi Gauss & Metode Eliminasi Gauss Jordan & Regresi Linear Berganda (**Abil**)
- SPL_Matriks Balikan & Matriks Balikan & Determinan & SPL_Kaidah Cramer (**Naufal**)
- Interpolasi Polinom & Interpolasi Bicubic (**Dhiwa**)

## Progress Tracker
- [x] Pembagian Tugas
- [x] SPL_Metode Eliminasi Gauss
- [x] SPL_Metode Eliminasi Gauss Jordan
- [x] SPL_Matriks Balikan
- [x] SPL_Kaidah Cramer
- [x] Determinan
- [x] Matriks Balikan
- [ ] Interpolasi Polinom
- [x] Interpolasi Bicubic
- [x] Regresi Linear Berganda
- [ ] Laporan
